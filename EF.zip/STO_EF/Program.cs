﻿using STO_EF;

using (DatabaseManager manager = new DatabaseManager())
{
    manager.FillDataBase();
}